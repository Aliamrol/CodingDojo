import datetime
import math


def calculateCost(x1, y1, x2, y2):
    ans = 0
    # to calculate the distance and the cost of it
    ans += math.sqrt(math.pow((x1 - x2), 2) + math.pow((y1 - y2), 2)) * 10
    # to check whether it's am or pm to calculate the cost of time
    t = datetime.datetime.now().strftime("%p")
    if t == "AM":
        ans += 30
    else:
        ans += 50
    return ans
