import Dopsi
import math

if __name__ == '__main__':
    dopsii = Dopsi()


# find best driver in accordance to distance, option and driver's income
def findTheBestDriver(trip):
    drivers = option(trip)
    distance = []
    # sort the drivers in accordance to distance
    for d in drivers:
        cost = math.sqrt(math.pow((d.xs - trip.xs), 2) + math.pow((d.ys - trip.ys), 2))
        li = []
        li.append(d)
        li.append(cost)
        distance.append(li)
    sort_distance = sorted(distance, key=lambda x: x[1])
    drivers = sort_distance[:5][0]
    drivers = sorted(drivers, key=lambda x: x.income)
    d = drivers[0]
    # calculate additional cost in accordance to the options
    plus = 0
    if d.AC == trip.AC and trip.AC == 1:
        plus += trip.cost * 0.15
    if d.music == trip.music and trip.music == 1:
        plus += trip.cost * 0.05
    if d.licensee == trip.licensee and trip.licensee == 1:
        plus += trip.cost * 0.1
    if d.specialNeeds == trip.specialNeeds and trip.specialNeeds == 1:
        plus += trip.cost * 0.2
    for t in dopsii.trips:
        if trip.id == t.id:
            t.cost += plus
    return d


def option(trip):
    drivers = []
    i = 0
    while True:
        for d in dopsii.drivers:
            dif = 0
            if d.AC != trip.AC:
                dif += 1
            if d.music != trip.music:
                dif += 1
            if trip.licensee != d.licensee:
                dif += 1
            if trip.specialNeeds != d.specialNeeds:
                dif += 1
            if dif == i:
                drivers.append(d)
        if len(drivers) != 0:
            break
        i += 1
    if i == 0:
        trip.cost += trip.plus

    return drivers
